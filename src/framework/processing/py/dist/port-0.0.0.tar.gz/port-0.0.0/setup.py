# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['port', 'port.api']

package_data = \
{'': ['*']}

install_requires = \
['panda>=0.3.1,<0.4.0']

setup_kwargs = {
    'name': 'port',
    'version': '0.0.0',
    'description': 'Port package with Data Donation logic',
    'long_description': None,
    'author': 'Emiel van der Veen',
    'author_email': 'e.vanderveen@eyra.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
